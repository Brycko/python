while True: 
        username = input("Please enter a username: ")
        if len(username) > 12:
            print("Error, Username needs to be shorter than 12 characters")
        else:
            break
score = 0
import linecache, random
#linecache and random used for line-reading and randomizing respectfully
print("Complete this quiz about the CEOP, answering these questions by entering A, B or C.")
#brief explantion
f = open("quizQuestions.txt","r")

level = 1
#level variable, stating that this is level 1
def question():
        #function for each question, virtually the same for each question but with different questions and varaibles. Questions are in functions so that they can be reordered in the randomizer
        global score, f
        #globalizing score and f variables
        print(f.readline())
        print("A:",f.readline())
        print("B:",f.readline())
        print("C:",f.readline())
        
        answer = input("Answer: ")
        if answer == "A" or answer == "a":
                print("Correct")
                score = score + 4
                #Checks if answer is correct, adds score to the scoreboard
        elif score == "B" or score == "b" or score == "C" or score == "c":
                print("Incorrect")
        else:
                print("Invalid Input")
                question()
                #input checker, repeats the question if input is invalid
def question2():
        global score, f
        print(linecache.getline("quizQuestions.txt",5))
        print("A:",linecache.getline("quizQuestions.txt",6))
        print("B:",linecache.getline("quizQuestions.txt",7))
        print("C:",linecache.getline("quizQuestions.txt",8))
        
        answer = input("Answer: ")
        if answer == "A" or answer == "a":
                print("Correct")
                score = score + 4
        elif answer == "B" or answer == "b" or answer == "C" or answer == "c":
                print("Incorrect")
        else:
                print("Invalid Input")
                question2()

def question3():
        global score, f
        print(linecache.getline("quizQuestions.txt",9))
        print("A:",linecache.getline("quizQuestions.txt",10))
        print("B:",linecache.getline("quizQuestions.txt",11))
        print("C:",linecache.getline("quizQuestions.txt",12))
        
        answer = input("Answer: ")
        if answer == "A" or answer == "a":
                print("Correct")
                score = score + 4
        elif answer == "B" or answer == "b" or answer == "C" or answer == "c":
                print("Incorrect")
        else:
                print("Invalid Input")
                question3()

def question4():
        global score, f
        print(linecache.getline("quizQuestions.txt",13))
        print("A:",linecache.getline("quizQuestions.txt",14))
        print("B:",linecache.getline("quizQuestions.txt",15))
        print("C:",linecache.getline("quizQuestions.txt",16))
        
        answer = input("Answer: ")
        if answer == "A" or answer == "a":
                print("Correct")
                score = score + 4
        elif answer == "B" or answer == "b" or answer == "C" or answer == "c":
                print("Incorrect")
        else:
                print("Invalid Input")
                question4()
def question5():
        global score, f
        print(linecache.getline("quizQuestions.txt",17))
        print("A:",linecache.getline("quizQuestions.txt",18))
        print("B:",linecache.getline("quizQuestions.txt",19))
        print("C:",linecache.getline("quizQuestions.txt",20))
        
        answer = input("Answer: ")
        if answer == "A" or answer == "a":
                print("Correct")
                score = score + 4
        elif answer == "B" or answer == "b" or answer == "C" or answer == "c":
                print("Incorrect")
        else:
                print("Invalid Input")
                question5()

#question randomizer, presents questions in random order every time
for x in range (0,5):
        order = random.randint(1,5)
        if order == 1:
                question()
        elif order == 2:
                question2()
        elif order == 3:
                question3()
        elif order == 4:
                question4()
        elif order == 5:
                question5()
#scoreprinter. Prints username, level and score variables in a sentence
print(username,"has completed level",level,"with a score of",score)
