while True:
    print("---------------------------------ScoreBoard---------------------------------")
    print("Option A: Show a player's score")
    print("Option B: Show the Highest Scores for each level")
    print("Option C: Show the Highest Scorer for each game")
    print("Option Q: Quit")
    option = input("Enter an Option: ")
    #prints menu, prompts input based on menu

    if option == "A" or option == "a":
    #Option A
        question = input("Enter playername >").lower()
        #asks for playername

        fi = open("playerScores.txt", "r")
        data=fi.readlines()
        fi.close     
            
        for li in data:
            if(li.split(",")[0].lower() == question):
                print("")
                print(question, "completed level", li.split(",")[1])
                print("with a score of", li.split(",")[2])
                #searches for playername, once found it prints the level and score
                
    if option == "B" or option == "b":
    #Option B
        fi = open("playerScores.txt", "r")
        lines=fi.readlines()

        li = 0
        l1highscore = 0
        l2highscore = 0
        l3highscore = 0
        l4highscore = 0
        l5highscore = 0
        score = 0
        for li in lines:
            level = int(li.split(",")[1])
            if level == 1:
                name = li.split(",")[0]
                score = int(li.split(",")[2])
                if score <= 20:
                    if score > l1highscore:
                        l1highscore = score
                        name1 = name
                    if score == l1highscore:
                        l1highscore = score
                        if name == name1:
                            name1 = name
                        else:
                            name1 = name + " and " + name1
            #First, it searches the file for all scores of level 1.
            #Then is sets the name and score to variables
            #It checks to see if the score is in the normal range (under 20)
            #It then compares it against the highest score, and sets the highest score to that number if it is greater than the high score
            #It also checks to see if the score is equal to the high score. If it is, it adds the name to the name variable, which will display more than one name for the highest score.
            if level == 2:
                name = li.split(",")[0]
                score = int(li.split(",")[2])
                if score <= 20:
                    if score > l2highscore:
                        l2highscore = score
                        name2 = name
                    if score == l2highscore:
                        l2highscore = score
                        if name == name2:
                            name2 = name
                        else:
                            name2 = name + " and " + name2
                            #Same is level 1, but with different variables
            if level == 3:
                name = li.split(",")[0]
                score = int(li.split(",")[2])
                if score <= 20:
                    if score > l3highscore:
                        l3highscore = score
                        name3 = name
                    if score == l3highscore:
                        l3highscore = score
                        if name == name3:
                            name3 = name
                        else:
                            name3 = name + " and " + name3
                            #Same is level 1, but with different variables
            if level == 4:
                name = li.split(",")[0]
                score = int(li.split(",")[2])
                if score <= 20:
                    if score > l4highscore:
                        l4highscore = score
                        name4 = name
                    if score == l4highscore:
                        l4highscore = score
                        if name == name4:
                            name4 = name
                        else:
                            name4 = name + " and " + name4
                            #Same is level 1, but with different variables
            if level == 5:
                name = li.split(",")[0]
                score = int(li.split(",")[2])
                if score <= 20:
                    if score > l5highscore:
                        l5highscore = score
                        name5 = name
                    if score == l5highscore:
                        l5highscore = score
                        if name == name5:
                            name5 = name
                        else:
                            name5 = name + " and " + name5
                            #Same is level 1, but with different variables
                        
        print("Level 1 Highscore: ",name1,"with a score of",l1highscore)
        print("Level 2 Highscore: ",name2,"with a score of",l2highscore)
        print("Level 3 Highscore: ",name3,"with a score of",l3highscore)
        print("Level 4 Highscore: ",name4,"with a score of",l4highscore)
        print("Level 5 Highscore: ",name5,"with a score of",l5highscore)
        #Prints the highest scores for each level.
        
    if option == "C" or option == "c":
    #Option C
    #Whilst working on this section of code, I displayed the playername, their previous player score, and the total player score.
        
        totalpscore = 0
        winningscore = 0
        
        fi = open("playerScores.txt", "r")
        lines = fi.readlines()
        fi.close
        
        for li in lines:
            playername = li.split(",")[0].lower()
            #assigns the player's name to a variable
            totalpscore = 0
            
            for li in lines:
                if(li.split(",")[0].lower() == playername):
                    thistime = int(li.split(",")[2].lower())
                    #checks against playername, to find the multiple records of the players score in playerScores.txt. If correct it assigns the score to variable thistime

                    if int(li.split(",")[1].lower()) > 6:
                        totalpscore = totalpscore
                        fi = open("scoreboard_errorlog.txt","a")
                        write = "LevelError: " + playername + ", level: " + li.split(",")[1].lower()
                        space = "\n"
                        fi.write(write)
                        fi.write(space)
                        fi.close
                        #Checks of the level is in the normal range. If not it is written to the errorlog.
                    else:
                        if thistime > 21:
                            totalpscore = totalpscore
                            fi = open("scoreboard_errorlog.txt","a")
                            write = "ScoreError: " + playername + ", Score: " + li.split(",")[2].lower()
                            space = "\n"
                            fi.write(write)
                            fi.write(space)
                            fi.close
                            #Checks of the score is in the normal range. If not it is written to the errorlog.
                        else:
                            totalpscore = thistime + totalpscore
                            #adds the current player score in question to the total player score

            if totalpscore > winningscore:
                winningscore = totalpscore
                winningplayer = playername
            elif totalpscore < winningscore:
                winningscore = winningscore
            elif totalpscore == winningscore:
                winningplayer == winningplayer + "and" + playername
            #the player's total score is checked against the winning score.
            #If larger, the playerscore becomes the winning score
            #if less, winningscore stays the same
            #if the same, players name added to variable winningplayer so that both names are displayed
            #This process is repeated for every player and his total score
        print("The Highest Scorer is",winningplayer,"with a Winning Score of",winningscore)
        #winning player and score displayed
            
    if option == "Q" or option == "q":
        exit()
    #quit option
