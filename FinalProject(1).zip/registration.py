print("Welcome! ")
print("Please enter your age, gender, preferred email address and a username.")
#Welcome screen
while True:
    playerage = int(input("Age: "))
    while True:
        playergender = input("Gender (M for male, F for Female, case-sensitive): ")
        if playergender == "M" or playergender == "F":
            break
        else:
            print("Error, please enter M or F")
            #Failsafe if entry is not M or F
    playeremail = input("Email Address: ")
    while True: 
        username = input("Username: ")
        if len(username) > 12:
            print("Error, Username needs to be shorter than 12 characters")
            #failsafe against usernames that are too long
        else:
            break
    print("Age:",playerage)
    print("Gender:",playergender)
    print("Email:",playeremail)
    print("Username:",username)
    confirm = input("Is this information correct? ")
    #info checker. Prints info and asks if correct
    if confirm == "yes" or confirm == "y":
        print("Thanks for registering!")
        exit()
        #if info is correct, registraiton closes
    elif confirm == "no" or confirm == "n":
        print("Please enter the correct information.")
        #repeats loop if info is not correct
        
